
import acm
def StartCreditLimitParameters( invokationInfo ):
    acm.UX().SessionManager().StartApplication("Credit Limit Parameters", None)
    
def StartCreditLimits( invokationInfo ):
    acm.UX().SessionManager().StartApplication("Credit Limits", None)
